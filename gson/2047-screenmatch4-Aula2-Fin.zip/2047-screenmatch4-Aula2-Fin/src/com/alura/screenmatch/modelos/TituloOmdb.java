package com.alura.screenmatch.modelos;

public record TituloOmdb(String title, String year, String runtime) {
}
